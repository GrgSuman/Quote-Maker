const express = require('express')
const {canvasImage,quoteMaker,singleQuoteMaker} = require("../controller/quoteMakerController")

const router = express.Router()

router.get("/quote-maker",quoteMaker)
router.get("/quote-maker/:id",singleQuoteMaker)
router.post("/getImageData",canvasImage)

module.exports=router