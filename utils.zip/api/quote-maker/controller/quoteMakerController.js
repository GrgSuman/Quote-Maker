const {canvasImageData} = require("../../../utils/canvasImage")
const {QuoteTemplate} = require("../model/QuoteTemplate")


//@desc Returns quote template with user entered quote and author and available template samples
//@GET quote/quote-maker?q="dsas"&a="asd"
//@access public 
const quoteMaker = async(req,res)=>{
    const{q,a} = req.query;
    if(!q){
        res.redirect("/")
    }
    const quoteTemplate = await QuoteTemplate.find().limit(10)
    quoteTemplate[0].quoteDetails.quote=q
    quoteTemplate[0].authorDetails.author=a
    const imgData = await canvasImageData(quoteTemplate[0])

    const data={
        "quote":q,
        "author":a,
        "showImage":imgData,
        "templates":quoteTemplate.slice(1),
    }
    res.render("pages/quoteMaker.ejs",data)
}

//@desc Returns quote template with user entered quote and author for specific id of template
//@GET quote/quote-maker/:id?q="dsas"&a="asd"
//@access public 
const singleQuoteMaker = async(req,res)=>{

    const{q,a} = req.query;
    if(!q){
        res.redirect("/")
    }

    const quoteTemplate = await QuoteTemplate.findById(req.params.id)
    const quoteTemplates = await QuoteTemplate.find({ _id: { $nin:req.params.id } }).limit(10)
    quoteTemplate.quoteDetails.quote=q
    quoteTemplate.authorDetails.author=a
    const imgData = await canvasImageData(quoteTemplate)

    const data={
        "quote":q,
        "author":a,
        "showImage":imgData,
        "templates":quoteTemplates,
    }
    res.render("pages/quoteMaker.ejs",data)
}


//@desc Dynamic quote generation based on imageData
//@GET quote/getImageData
//@access public 
const canvasImage = async(req,res)=>{
    const imgData = await canvasImageData(req.body)
    const data={
        msg:"success",
        imageData:imgData
    }
    res.json(data)
}

module.exports={
    canvasImage,
    quoteMaker,
    singleQuoteMaker
}